from django.urls import path
from . import views

#UrlConf
urlpatterns = [
    path('fare',views.predict_fare , name='predict_fare'),
]
