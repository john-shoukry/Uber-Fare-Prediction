import pandas as pd
import numpy as np
import joblib
from django.shortcuts import render

model = joblib.load('farepredictor/xgb_taxi_fare_model.pkl')

def predict_fare(request):
    if request.method == 'POST':
        # Column names in exact order expected by model
        column_names = [
            'Car Condition', 'Weather', 'Traffic Condition', 'pickup_datetime',
            'pickup_longitude', 'pickup_latitude', 'dropoff_longitude',
            'dropoff_latitude', 'passenger_count', 'hour', 'day', 'month',
            'weekday', 'year', 'jfk_dist', 'ewr_dist', 'lga_dist', 'sol_dist',
            'nyc_dist', 'distance', 'bearing'
        ]

        # Get features from the form
        features = [
    request.POST.get('car_condition'),
    request.POST.get('weather'),
    request.POST.get('traffic_condition'),
    request.POST.get('pickup_datetime'),
    float(request.POST.get('pickup_longitude', 0)),
    float(request.POST.get('pickup_latitude', 0)),
    float(request.POST.get('dropoff_longitude', 0)),
    float(request.POST.get('dropoff_latitude', 0)),
    int(request.POST.get('passenger_count', 1)),
    int(request.POST.get('hour', 0)),
    int(request.POST.get('day', 0)),
    int(request.POST.get('month', 0)),
    int(request.POST.get('weekday', 0)),
    int(request.POST.get('year', 0)),
    float(request.POST.get('jfk_dist', 0)),
    float(request.POST.get('ewr_dist', 0)),
    float(request.POST.get('lga_dist', 0)),
    float(request.POST.get('sol_dist', 0)),
    float(request.POST.get('nyc_dist', 0)),
    float(request.POST.get('distance', 0)),
    float(request.POST.get('bearing', 0))
        ]


        # Convert to DataFrame with correct column names
        input_df = pd.DataFrame([features], columns=column_names)

        # Predict
        prediction = model.predict(input_df)[0]

        return render(request, 'farepredictor/result.html', {'fare': round(prediction, 2)})

    return render(request, 'farepredictor/predict.html')
